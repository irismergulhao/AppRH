package com.AppRH.AppRH;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppRhApplicationTests {

	@Test
	void contextLoads() {
	}

}
